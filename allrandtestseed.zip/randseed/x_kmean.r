a<-scan("kmeanfea.txt")
x <- matrix(a, ncol = 2000, byrow=TRUE)
set.seed(199643)
km.res=kmeans(x,6,iter.max = 1000, nstart = 25,
       algorithm = c("Hartigan-Wong", "Lloyd", "Forgy",
                     "MacQueen"), trace=FALSE)
print(km.res)
