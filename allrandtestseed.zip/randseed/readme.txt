This only test level one clustering with 100 random seeds
Also make sure the  silscore_avedis is compiled for your current machine.

to do test:
./scan_loopk_dis_randseed.job

result:
dis_all_randseed_k.dat
column 5 is SC score
