This only test level one clustering with 100 randomly  shuffled assignment to original clusters, thus the original clustering result 
must be in ../output 
Also make sure the  silscore_avedis_ss is compiled for your current machine.

to do test:
./scan_loopk_dis_randshuffle.job
result:
dis_randshuffle_k.dat
column 5 is SC score
